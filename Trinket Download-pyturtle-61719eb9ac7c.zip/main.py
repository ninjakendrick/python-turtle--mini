import turtle

i = 0
n = 0
q = 0
k = 0
o = 0
l = 0

line_name = 1
print("welcome to pyturtle+ type run to run your code")

function_name = False
code = []
forward_distance = []
backward_distance = []
right_turns = []
left_turns = []
color = ["blue","green","black","orange","yellow","white","purple","red","pink"]
color_chosen = []
loop = []
run = True
loop_on = False
code_run = False
loop_list = []
function_on = False
function_list = []
loops = 0

while run:
    line = input("line "+str(line_name)+":")
    line_name = line_name + 1

    if line == "run":
        run = False

    elif line == "forward":
        try:
            forward_num = int(input("how much steps do you want the turtle to move"))
            forward_distance.append(forward_num)
            if loop_on == False and function_on == False:
                code.append(line)
            elif loop_on:
                loop_list.append(line)
            else:
                function_list.append(line)
        except:
            print("syntax error make sure you typed a number")

    elif line == "backward":
        try:
            backward_num = int(input("how much steps do you want the turtle to move backward"))
            backward_distance.append(backward_num)
            if loop_on == False and function_on == False:
                code.append(line)
            elif loop_on:
                loop_list.append(line)
            else:
                function_list.append(line)
        except:
            print("syntax error make sure you typed a number")

    elif line == "right":
        try:
            right_num = int(input("how much degrees do you want the turtle to turn right"))
            right_turns.append(right_num)
            if loop_on == False and function_on == False:
                code.append(line)
            elif loop_on:
                loop_list.append(line)
            else:
                function_list.append(line)
        except:
            print("syntax error make sure you typed a number")

    elif line == "left":
        try:
            left_num = int(input("how much steps do you want the turtle to turn left"))
            left_turns.append(left_num)
            if loop_on == False and function_on == False:
                code.append(line)
            elif loop_on:
                loop_list.append(line)
            else:
                function_list.append(line)
        except:
            print("syntax error make sure you typed a number")

    elif line == "penup":
        if loop_on == False and function_on == False:
            code.append(line)
        elif loop_on:
            loop_list.append(line)
        else:
            function_list.append(line)

    elif line == "pendown":
        if loop_on == False and function_on == False:
            code.append(line)
        elif loop_on:
            loop_list.append(line)
        else:
            function_list.append(line)

    elif line == "color":
        turtle_color = input("what color do you want the turtle to be")
        if turtle_color in color:
            color_chosen.append(turtle_color)
            if loop_on == False and function_on == False:
                code.append(line)
            elif loop_on:
                loop_list.append(line)
            else:
                function_list.append(line)
        else:
            print("syntax error: make sure you type a color")

    elif line == "start_loop" or line == "start loop":
        try:
            loops = int(input("how much loops do you want"))
            code.append("start_loop")
            loop_on = True
            loop_list = []
        except:
            print("type a number")

    elif line == "end_loop" or line == "end loop":
        if loop_on == True:
            code.append("end_loop")
            loop_on = False
        else:
            print("make sure have a start loop command at the top")

    elif line == "start_function" or line == "start function":
        function_name = input("what do you want your function to be called")
        function_on = True
        function_list = []
        code.append("start_function")

    elif line == "end_function" or line == "end function":
        if function_on == True:
            code.append("end_function")
            function_on = False
        else:
            print("make sure you have a start function command at the top")

    elif line == function_name:
        code.append(line)

    else:
        code.append(line)


# ---------------- FUNCTION EXTRACTION ----------------

functions = {}
i = 0

while i < len(code):
    if code[i] == "start_function":
        function_list = []
        i += 1
        while code[i] != "end_function":
            function_list.append(code[i])
            i += 1
        functions[function_name] = function_list
    i += 1


# ---------------- EXECUTION ----------------

i = 0
while i < len(code):

    if code[i] == "forward":
        turtle.forward(forward_distance[n])
        n += 1

    elif code[i] == "penup":
        turtle.penup()

    elif code[i] == "pendown":
        turtle.pendown()

    elif code[i] == "backward":
        turtle.backward(backward_distance[o])
        o += 1

    elif code[i] == "right":
        turtle.right(right_turns[q])
        q += 1

    elif code[i] == "left":
        turtle.left(left_turns[k])
        k += 1

    elif code[i] == "color":
        turtle.color(color_chosen[l])
        l += 1

    elif code[i] == "start_loop":
        loop_on = True
        code_run = True

    elif code[i] == "end_loop":
        loop_on = False
        for _ in range(loops):
            loop_n = 0
            loop_o = 0
            loop_q = 0
            loop_k = 0
            loop_l = 0

            for j in range(len(loop_list)):

                if loop_list[j] == "forward":
                    turtle.forward(forward_distance[loop_n])
                    loop_n += 1

                elif loop_list[j] == "backward":
                    turtle.backward(backward_distance[loop_o])
                    loop_o += 1

                elif loop_list[j] == "right":
                    turtle.right(right_turns[loop_q])
                    loop_q += 1

                elif loop_list[j] == "left":
                    turtle.left(left_turns[loop_k])
                    loop_k += 1

                elif loop_list[j] == "color":
                    turtle.color(color_chosen[loop_l])
                    loop_l += 1

                elif loop_list[j] == "penup":
                    turtle.penup()

                elif loop_list[j] == "pendown":
                    turtle.pendown()

    elif code[i] == function_name:

        fn = 0
        fo = 0
        fq = 0
        fk = 0
        fl = 0

        for x in range(len(function_list)):

            if function_list[x] == "forward":
                turtle.forward(forward_distance[fn])
                fn += 1

            elif function_list[x] == "backward":
                turtle.backward(backward_distance[fo])
                fo += 1

            elif function_list[x] == "right":
                turtle.right(right_turns[fq])
                fq += 1

            elif function_list[x] == "left":
                turtle.left(left_turns[fk])
                fk += 1

            elif function_list[x] == "color":
                turtle.color(color_chosen[fl])
                fl += 1

            elif function_list[x] == "penup":
                turtle.penup()

            elif function_list[x] == "pendown":
                turtle.pendown()

    i += 1

turtle.done()
